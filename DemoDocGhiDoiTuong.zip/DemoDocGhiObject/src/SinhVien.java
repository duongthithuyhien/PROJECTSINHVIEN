import java.io.Serializable;


public class SinhVien implements Serializable{
	
	private int maSV;
	private String tenSV;

	
	public SinhVien(int maSV, String tenSV) {
		super();
		this.maSV = maSV;
		this.tenSV = tenSV;
	}
	public SinhVien() {
		// TODO Auto-generated constructor stub
	}
	public int getMaSV() {
		return maSV;
	}
	public void setMaSV(int maSV) {
		this.maSV = maSV;
	}
	public String getTenSV() {
		return tenSV;
	}
	public void setTenSV(String tenSV) {
		this.tenSV = tenSV;
	}
	
	public String toString() {
		// TODO Auto-generated method stub
		return maSV + " - " + tenSV;
	}
	

}
