
public class KiemTraDocGhiSV {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		SinhVien sv1 = new SinhVien(1, "Nguyen Van An");
		new DocGhiSV().GhiDoiTuongSV(sv1);
		new DocGhiSV().DocDoiTuongSV(sv1);
	}

}
