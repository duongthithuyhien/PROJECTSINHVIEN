import java.util.ArrayList;


public class KiemTraDocGhiSV {

	public static void main(String[] args) {

		SinhVien sv1 = new SinhVien(1, "Nguyen Van An");
		SinhVien sv2 = new SinhVien(2, "Nguyen Van Ba");
		new DocGhiSV().GhiDoiTuongSV(sv1);
		new DocGhiSV().DocDoiTuongSV();
		
		ArrayList<SinhVien> dssv = new ArrayList<SinhVien>();
		dssv.add(sv1);
		dssv.add(sv2);
		
		new DocGhiSV().GhiDSSV(dssv);
		new DocGhiSV().DocDSSV();
		
	}

}
