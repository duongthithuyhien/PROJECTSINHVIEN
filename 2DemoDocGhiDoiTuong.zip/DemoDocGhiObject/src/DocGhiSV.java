import java.awt.List;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


public class DocGhiSV {


	public void GhiDoiTuongSV(SinhVien sv)
	{
		try {
			
			
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("D:\\sinhvien.ser")));
			objectOutputStream.writeObject(sv);
			objectOutputStream.close();
			System.out.println("Ghi thanh cong!");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void GhiDSSV(ArrayList<SinhVien> dssv)
	{
		try {
			
			
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("D:\\dssinhvien.ser")));
			objectOutputStream.writeObject(dssv);
			objectOutputStream.close();
			System.out.println("Ghi danh sach sv thanh cong!");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void DocDoiTuongSV()
	{
		try {
			
			SinhVien sv1 = new SinhVien();
			ObjectInputStream objectOutputStream = new ObjectInputStream(new BufferedInputStream(new FileInputStream("D:\\sinhvien.ser")));
			try {
				sv1 =(SinhVien) objectOutputStream.readObject();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			objectOutputStream.close();
			
			System.out.println(sv1.toString());
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	@SuppressWarnings("unchecked")
	public void DocDSSV()
	{
		try {
			
			ArrayList<SinhVien> dssv = new ArrayList<SinhVien>();
			ObjectInputStream objectOutputStream = new ObjectInputStream(new BufferedInputStream(new FileInputStream("D:\\dssinhvien.ser")));
			try {
				dssv =(ArrayList<SinhVien>) objectOutputStream.readObject();
				for (int i = 0; i < dssv.size(); i++) {
					System.out.println(dssv.get(i).toString());
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			objectOutputStream.close();
			
			//System.out.println(sv1.toString());
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
